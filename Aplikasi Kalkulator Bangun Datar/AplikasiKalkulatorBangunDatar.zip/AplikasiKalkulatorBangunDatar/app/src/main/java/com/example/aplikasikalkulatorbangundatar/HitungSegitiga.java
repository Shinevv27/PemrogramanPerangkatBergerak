 package com.example.aplikasikalkulatorbangundatar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

 public class HitungSegitiga extends AppCompatActivity {

     private EditText alas, tinggi, sisi;
     private Button hasilluas, hasilkeliling;
     private TextView luasnya, kelilingnya;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_hitung_segitiga);
         alas = (EditText) findViewById(R.id.alas);
         tinggi = (EditText) findViewById(R.id.tinggi);
         sisi = (EditText) findViewById(R.id.sisi);
         hasilluas = (Button) findViewById(R.id.hasilluas);
         hasilkeliling = (Button) findViewById(R.id.hasilkeliling);
         luasnya = (TextView) findViewById(R.id.luasnya);
         kelilingnya = (TextView) findViewById(R.id.kelilingnya);
     }

     public void Kirim(View view) {
         try{
             int a = Integer.parseInt(alas.getText().toString());
             int t = Integer.parseInt(tinggi.getText().toString());
             int hasilluas = (a*t)/2;
             luasnya.setText(String.valueOf(hasilluas));
             } catch (Exception e){
             e.printStackTrace();
         }
     }

     public void Kirim2(View view) {
         try{
             int s = Integer.parseInt(sisi.getText().toString());
             int hasilkeliling = (3*s);
             kelilingnya.setText(String.valueOf(hasilkeliling));
         } catch (Exception e){
             e.printStackTrace();
         }
     }
 }
