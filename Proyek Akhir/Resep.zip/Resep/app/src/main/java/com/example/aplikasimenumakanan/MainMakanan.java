 package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Locale;

 public class MainMakanan extends AppCompatActivity {

     ListView listView;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main_makanan);

         String nama_makanan[] = {"Brokoli dan Ayam",
                 "Oatmel Yoghurt",
                 "Avocado Toast"
         };

         int gambar_makanan[] = {R.drawable.brokolidanayam,
                 R.drawable.oatmealyoghurt,
                 R.drawable.avocadotoast
         };

         String deskripsi_makanan[] = {"Bahan yang diperlukan:\n" +
                "\n" +
                "- 1 buah Brokoli\n" +
                "- 1 buah Jagung\n" +
                "- 1 telur ayam\n" +
                "- 1 ayam strip pedas\n" +
                "\n" +
                "Cara memasak:\n" +
                "\n" +
                "1. Rebus semua bahan\n" +
                "2. Goreng ayam strip pedas\n" +
                "3. Sajikan pakai saus",

                "Bahan yang diperlukan:\n" +
                "\n" +
                "- 4 sdm oatmeal\n" +
                "- 4 sdm air panas\n" +
                "- 100 ml susu cair\n" +
                "- 3 sdm yogurt\n" +
                "- Buah Strawberry, Blueberry, Pisang,\n " +
                "  Apel, atau sesuai selera\n" +
                "\n" +
                "Cara memasak:\n" +
                "\n" +
                "1. Campurkan oatmeal dan air panas \n " +
                "    hingga empuk.\n" +
                "2. Jika menggunakan oat utuh, masak \n" +
                "    oatmeal hingga empuk.\n" +
                "3. Tuang susu dan yogurt ke dalam \n" +
                "    oatmeal.\n" +
                "4. Aduk rata, tambahkan buah-buahan \n" +
                "    sesuai selera.\n" +
                "5. Oatmeal yoghurt siap dinikmati.",

                "Bahan yang diperlukan:\n" +
                "\n" +
                "- 1/2 buah alpukat, potong tipis-tipis\n" +
                "- 2 lembar roti tawar gandum\n" +
                "- 2 buah telur\n" +
                "- Biji-bijian seperti Biji Falxseed, Biji Wijen \n" +
                "  dan Biji Bunga Matahari (Opsional)\n" +
                "\n" +
                "Cara memasak:\n" +
                "\n" +
                "1. Toast roti atau panggang dengan \n" +
                "    teflon.\n" +
                "2. Jika roti sudah agak mengeras dan \n" +
                "    berwarna kecoklatan. Angkat roti. \n" +
                "    Lalu sisihkan.\n" +
                "3. Ceplok telur setengah matang. \n " +
                "    Sisihkan.\n" +
                "4. Plating. Taruh alpukat di atas roti, \n" +
                "    lalu tambahkan telur di atasnya. \n" +
                "    Taburkan biji-bijian. Sajikan."
         };

         listView = findViewById(R.id.Listdatamakanan);
         AdapterMakanan adapterMakanan = new AdapterMakanan(this, nama_makanan, deskripsi_makanan, gambar_makanan);
         listView.setAdapter(adapterMakanan);
         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                 String nm_makanan=nama_makanan[position].toString();
                 int gbr_makanan=gambar_makanan[position];
                 String des_makanan=deskripsi_makanan[position].toString();

                 //Toast.makeText(MainMakanan.this, ""+nm_makanan.trim(), Toast.LENGTH_SHORT).show();
                 Intent intent = new Intent(MainMakanan.this, DetailMakanan.class);
                 intent.putExtra("nmakanan",nm_makanan);
                 intent.putExtra("gmakanan",gbr_makanan);
                 intent.putExtra("des",des_makanan);
                 startActivity(intent);
             }
         });
     }
 }