package com.example.aplikasibiodata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void KirimData(View view) {
        Intent intent, chooser;
        intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://goo.gl/maps/J8bp8RmsPA2NcNuE8"));
        chooser = Intent.createChooser(intent, "Launch Map");
        startActivity(chooser);
    }

    public void KirimData1(View view) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:0895363877949"));
        startActivity(intent);
    }

    public void KirimData2(View view) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"111202013189@mhs.dinus.ac.id"});
        startActivity(intent);
    }
}