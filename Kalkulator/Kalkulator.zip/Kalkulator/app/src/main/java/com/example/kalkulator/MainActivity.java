package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText angka1, angka2;
    RadioButton tambah, kurang, kali, bagi;
    Button hitung;
    TextView hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        angka1=(EditText) findViewById(R.id.angka1);
        angka2=(EditText) findViewById(R.id.angka2);
        tambah=(RadioButton) findViewById(R.id.tambah);
        kurang=(RadioButton) findViewById(R.id.kurang);
        kali=(RadioButton) findViewById(R.id.kali);
        bagi=(RadioButton) findViewById(R.id.bagi);
        hitung=(Button) findViewById(R.id.hitung2);
        hasil=(TextView) findViewById(R.id.hasil);
    }

    public void Klik(View view) {
        String p = null;
        if(tambah.isChecked()){p="Tambah";}
        else if(kurang.isChecked()){p="Kurang";}
        else if(kali.isChecked()){p="Kali";}
        else if(bagi.isChecked()){p="Bagi";}

        String a1= angka1.getText().toString();
        String a2= angka2.getText().toString();
        double ang1= Double.parseDouble(a1);
        double ang2= Double.parseDouble(a2);
        double hsl=0;

        if(p.equalsIgnoreCase("Tambah")){
            hsl=ang1+ang2;
        }
        else if(p.equalsIgnoreCase("Kurang")){
            hsl=ang1-ang2;
        }
        else if(p.equalsIgnoreCase("Kali")){
            hsl=ang1*ang2;
        }
        else if(p.equalsIgnoreCase("Bagi")){
            hsl=ang1/ang2;
        }
        String h=String.valueOf(hsl);
        hasil.setText(h);
    }


}